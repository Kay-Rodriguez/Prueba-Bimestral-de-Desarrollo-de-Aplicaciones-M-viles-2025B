## Integrantes del Grupo

- **Sebastian Betancourt**
- **Justin Imbaquingo**    
- **Danna Lopez** 
- **Karla Rodriguez** 
- **Alisson Viracocha**  

---

### 🔹 Implementación de carga y subida de fotos - Danna Lopez* 

<img width="347" height="543" alt="image" src="https://github.com/user-attachments/assets/aa34337a-ea0d-44ec-954b-d339cdf879fa" />

Las fotos se guardan inmediatamente en el local storage del navegador (F12 ----> Aplicacion ----> Local Storage)

<img width="768" height="544" alt="image" src="https://github.com/user-attachments/assets/bb52cd4e-b262-457e-90a4-ba31dae66a6e" />


### Carga y Guardado de fotos (Alisson Viracocha)
<img width="602" height="647" alt="image" src="https://github.com/user-attachments/assets/79c6e1e1-c890-4993-b28e-4bc85ed7044d" />
<img width="672" height="673" alt="image" src="https://github.com/user-attachments/assets/8470ad56-b6c8-41e8-bcff-be0bc73c5e97" />ón 

---

### 🔹 Implementación por *Justin Imbaquingo*
<div align="center">
  <img src="https://github.com/user-attachments/assets/f181941d-ed5a-490a-b661-8545c8b6d417" width="95%" />
  <img src="https://github.com/user-attachments/assets/ca84d660-0008-4443-a3ba-16c4021add59" width="95%" />
</div>

---

### 🔹 Implementación por *Sebastián Betancourt*
<div align="center">
  <img src="https://github.com/user-attachments/assets/048ff924-34ee-4e1e-b36d-c785c9f55725" width="95%" />
  <img src="https://github.com/user-attachments/assets/4dbe8208-e83e-41a9-841d-63ac1d4042c3" width="95%" />
</div>

---
### 🔹 Implementación por *Karla Rodriguez*
<div align="center">
<<img width="1338" height="676" alt="image" src="https://github.com/user-attachments/assets/f3566b1d-6332-4ae7-bf95-92f71900562b" />
<img width="673" height="643" alt="image" src="https://github.com/user-attachments/assets/5d8a6a53-86d9-4b81-b228-87af595bc40f" />
</div>
